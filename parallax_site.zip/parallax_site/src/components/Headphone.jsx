import React from "react";
export default function Headphone(){
  return <img id="headphone" src="/assets/headphones.png" alt="Headphone" />;
}
